<footer class=" bg-light py-4 mt-auto w-100 border-top">
    <div class="text-center">
        <p class="mb-0">&copy; 2024 Auction Inc. All rights reserved.</p>
    </div>
</footer>

<style>
    .border-top{
        border-top-color: #ddd;
    }
</style>