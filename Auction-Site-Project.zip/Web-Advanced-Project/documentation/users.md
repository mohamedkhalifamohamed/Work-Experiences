# Users

Place the credentials for at least two users in the table below. There should be at least one administrator and one regular user.


| Username(email) | Password | Account type |
|---------------|------|------------|
| `alice@gmail.com` | AlicePassword123 | Admin      |
| `bob@gmail.com`   |  BobPassword456  | User       |
| `charlie@gmail.com`|  CharliePassword789 | User       |


