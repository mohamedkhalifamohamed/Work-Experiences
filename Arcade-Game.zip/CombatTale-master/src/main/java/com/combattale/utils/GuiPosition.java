package com.combattale.utils;

public enum GuiPosition {
    LEFT_TOP,
    CENTER_TOP,
    RIGHT_TOP,
    LEFT_CENTER,
    CENTER,
    RIGHT_CENTER,
    LEFT_BOTTOM,
    CENTER_BOTTOM,
    RIGHT_BOTTOM
}
