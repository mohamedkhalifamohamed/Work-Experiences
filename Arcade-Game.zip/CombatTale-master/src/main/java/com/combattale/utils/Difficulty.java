package com.combattale.utils;

public enum Difficulty {
    EASY,
    NORMAL,
    EXTREME
}
